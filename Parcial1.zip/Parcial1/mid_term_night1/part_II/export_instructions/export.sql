--------------------------------------------------------
-- Archivo creado  - mi�rcoles-octubre-11-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ANSWERS
--------------------------------------------------------

  CREATE TABLE "ANSWERS" 
   (	"id" NUMBER(*,0), 
	"number_of_question" VARCHAR2(255), 
	"answer" VARCHAR2(255)
   )
--------------------------------------------------------
--  DDL for Table CATEGORIES
--------------------------------------------------------

  CREATE TABLE "CATEGORIES" 
   (	"id" NUMBER(*,0), 
	"name" VARCHAR2(255), 
	"season" VARCHAR2(255)
   )
--------------------------------------------------------
--  DDL for Table PRODUCTS
--------------------------------------------------------

  CREATE TABLE "PRODUCTS" 
   (	"id" NUMBER(*,0), 
	"name" VARCHAR2(255), 
	"reference" VARCHAR2(255), 
	"price" NUMBER(10,3), 
	"category_id" NUMBER(*,0)
   )
--------------------------------------------------------
--  DDL for Sequence LOGMNR_EVOLVE_SEQ$
--------------------------------------------------------

   CREATE SEQUENCE  "LOGMNR_EVOLVE_SEQ$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence LOGMNR_SEQ$
--------------------------------------------------------

   CREATE SEQUENCE  "LOGMNR_SEQ$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  ORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence LOGMNR_UIDS$
--------------------------------------------------------

   CREATE SEQUENCE  "LOGMNR_UIDS$"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 100 NOCACHE  ORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence MVIEW$_ADVSEQ_GENERIC
--------------------------------------------------------

   CREATE SEQUENCE  "MVIEW$_ADVSEQ_GENERIC"  MINVALUE 1 MAXVALUE 4294967295 INCREMENT BY 1 START WITH 1 CACHE 50 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence MVIEW$_ADVSEQ_ID
--------------------------------------------------------

   CREATE SEQUENCE  "MVIEW$_ADVSEQ_ID"  MINVALUE 1 MAXVALUE 4294967295 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_EXCEPTIONS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_EXCEPTIONS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_FLAVOR_NAME_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_FLAVOR_NAME_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_FLAVORS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_FLAVORS_S"  MINVALUE -2147483647 MAXVALUE 2147483647 INCREMENT BY 1 START WITH 1 NOCACHE  NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT_LOG_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT_LOG_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_REFRESH_TEMPLATES_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_REFRESH_TEMPLATES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_REPPROP_KEY
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_REPPROP_KEY"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_RUNTIME_PARMS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_RUNTIME_PARMS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_OBJECTS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_TEMPLATE_OBJECTS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_PARMS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_TEMPLATE_PARMS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_REFGROUPS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_TEMPLATE_REFGROUPS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMPLATE_SITES_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_TEMPLATE_SITES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_TEMP_OUTPUT_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_TEMP_OUTPUT_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_USER_AUTHORIZATIONS_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_USER_AUTHORIZATIONS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence REPCAT$_USER_PARM_VALUES_S
--------------------------------------------------------

   CREATE SEQUENCE  "REPCAT$_USER_PARM_VALUES_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
--------------------------------------------------------
--  DDL for Sequence TEMPLATE$_TARGETS_S
--------------------------------------------------------

   CREATE SEQUENCE  "TEMPLATE$_TARGETS_S"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE
REM INSERTING into ANSWERS
SET DEFINE OFF;
Insert into ANSWERS ("id","number_of_question","answer") values ('1','1','0');
Insert into ANSWERS ("id","number_of_question","answer") values ('2','2','963');
Insert into ANSWERS ("id","number_of_question","answer") values ('3','3','8C402EDA-D7D5-540D-3974-4EB9C810E3D6');
Insert into ANSWERS ("id","number_of_question","answer") values ('4','4','vel sapien');
Insert into ANSWERS ("id","number_of_question","answer") values ('5','5','swin wear');
REM INSERTING into CATEGORIES
SET DEFINE OFF;
Insert into CATEGORIES ("id","name","season") values ('1','shoes','winter');
Insert into CATEGORIES ("id","name","season") values ('2','shoes','summer');
Insert into CATEGORIES ("id","name","season") values ('3','swim wear','summer');
Insert into CATEGORIES ("id","name","season") values ('4','tennis','summer');
Insert into CATEGORIES ("id","name","season") values ('5','ski','winter');
Insert into CATEGORIES ("id","name","season") values ('6','snowboard','winter');
Insert into CATEGORIES ("id","name","season") values ('7','golf','summer');
Insert into CATEGORIES ("id","name","season") values ('8','diving equipment','summer');
Insert into CATEGORIES ("id","name","season") values ('9','running wear','summer');
Insert into CATEGORIES ("id","name","season") values ('10','fitness gear','summer');
Insert into CATEGORIES ("id","name","season") values ('11','fitness gear','winter');
REM INSERTING into PRODUCTS
SET DEFINE OFF;
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1000','enim. Mauris','8C402EDA-D7D5-540D-3974-4EB9C810E3D6','10','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1005','libero.','68D3F0AC-7061-112A-BD4B-AD1A8108156A','378','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1010','fames ac turpis','47AF013F-1611-2695-F069-990726B02BCD','732','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1015','fringilla.','AA3BECCF-1E18-EC21-0B0E-6E60D26E9515','878','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1020','Phasellus','92AD2936-611E-08D8-F14C-C55F55D7448D','476','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1025','eu,','204BD401-0613-75B3-1C9B-54F40D7EBE9F','766','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1030','metus vitae velit','7872B045-09BD-E3D9-94FE-FB1077F17672','853','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1035','vehicula','DC068ED5-59F6-0768-5C9E-1CE365F04D27','983','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1040','nec orci.','1D4B3F9C-BC28-B5B8-79C4-540FFA5A2BCE','23','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1045','Nullam lobortis quam','F38E68D8-9C9F-26AE-17A2-BB2323CA77F4','69','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1050','molestie. Sed','0471FD30-E544-B4C1-81B6-0CB4E0E4F98E','16','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1055','Sed nulla','235D318D-3CB1-A608-4767-C7BBFF485A9E','128','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1060','mauris, rhoncus id,','F1F99B39-AC78-267D-BC90-E1017C797D50','244','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1065','neque.','D976177B-1727-BCA3-6F37-7A177BDE4A91','473','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1070','In at pede.','02085DAE-38CC-8DD5-EB78-647A3CE01B25','16','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1075','ante dictum mi,','A71B05A8-D87B-D9FD-E7DE-24EBF7E83560','704','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1080','Sed nec','1C7683F9-4E09-890F-56D6-A22864D45824','437','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1085','non,','F13EA293-12F8-5412-4C7D-1251749CC866','81','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1090','lorem. Donec elementum,','E656DCC2-0C97-1ABD-F1B4-36749916FF8A','514','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1095','neque','114BAB51-79CC-E3B1-AC3B-813E89F9619A','819','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1100','sed dictum eleifend,','9CFE31B6-D922-0879-4B58-E51F700C4ED7','976','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1105','Quisque ornare','46F8701A-751F-817B-6A2E-9DF9530DAC67','629','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1110','risus. Donec','D7457DC7-EE43-5E11-5E89-34BC60841BEB','114','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1115','Nam consequat dolor','015F571B-BAEC-5FAC-0438-8B2D1CB2C593','516','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1120','Proin','92641422-8B21-17E1-5CAA-E18F26D9793D','804','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1125','Nunc','5BD8CF36-52F4-C474-03EB-684327EEBB28','772','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1130','ultrices.','895339C6-6F84-464D-E038-5E22119984F2','215','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1135','lacus. Quisque','020FBA07-F452-CF76-28E2-A4F2A26618C0','201','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1140','fringilla est. Mauris','8288ABC1-49D2-6901-57CA-D7DE7D97E353','187','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1145','lectus, a sollicitudin','860A8D2C-9BA5-BA39-5595-C8C9463DA7DA','216','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1150','et malesuada fames','B736B56A-A2BF-7748-436D-01A0E30E9602','55','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1155','leo.','DA72C1C7-5954-B1D6-B845-90B7DED51DD2','111','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1160','vulputate','594EE71A-D673-F58D-256C-2E9641D40333','180','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1165','a,','00DB3399-4B86-1688-148E-EACCD6B1F7AF','783','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1170','Ut semper','8259DAD0-A938-B230-0B2D-C67ACF1966A0','370','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1175','dictum mi,','751853B6-77C8-CC2A-93FB-B2D1948A0D53','699','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1180','ut quam vel','4BA71AE1-AC60-7BBA-A582-093AB2BD369C','92','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1185','neque','61F117DA-5779-D172-69A5-48D786E3A369','618','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1190','magnis dis','8E72D1EC-5F01-0B29-5149-7D7EC556187E','986','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1195','ac','8CE4B587-71A6-4553-F57B-DE4C5CB3BF09','522','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1200','elit fermentum','1209D9A9-D8C1-7A43-F800-695202B81CF4','610','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1205','laoreet','23203874-FC31-8A2C-97ED-000882AC4803','3','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1210','sapien molestie','37C679D2-1C72-53B3-BABA-1429997A9F34','442','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1215','ipsum dolor','EDE5AB0B-4233-109C-805D-559F194833B2','658','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1220','sed','22006C22-A98C-6FBF-24DB-AADDA024B88C','511','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1225','ut','6D5122AB-BEB3-F5B4-4314-DD941C3A4D2A','934','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1230','Donec feugiat metus','1048938E-9627-3B28-E91C-9548A0B6FB96','739','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1235','vitae,','A9C20976-60F5-6855-DB79-C7D7FC9EBECB','863','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1240','enim.','E89FF7FB-339B-46F8-8249-2044FA3F467A','635','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1245','nunc','08910045-EC68-9C34-37DA-BA693F534A40','855','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1250','ultrices','1F064187-E60B-C277-A1C6-1B9A7EDD2766','83','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1255','lorem,','B7F36BFC-CB02-A8EF-8882-F6504B096150','780','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1260','id,','EA72E4E6-851F-8050-A08C-4FA71FF68FA2','888','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1265','sed','0A813B63-DD77-984B-5B18-8F4B1594D25D','572','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1270','enim. Mauris','F4D1DADC-BB93-CB9F-E076-8040D5F16767','498','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1275','nec tempus','C7B5A74D-CB4B-01DC-E694-1F6DCBEB0554','979','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1280','odio. Nam','E3F29201-C8C7-273C-6608-35AE959641A0','277','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1285','luctus aliquet odio.','B98CD897-D389-F40F-B690-C228435AA1FE','216','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1290','risus.','2A7B4862-F654-C095-A5C1-279D2497362A','176','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1295','sem','C8EB2DFB-6DC5-C327-4669-2A4EAC4FF8EB','766','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1300','pede ac urna.','B813FE56-EDF2-1811-CD3C-05DC39D57216','379','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1305','tristique','A5870ECF-CC3B-D47E-D32B-A09A05E16C6D','355','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1310','non massa non','C734CED2-46E5-C428-3737-C916C997969F','143','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1315','vitae','A6753CF1-6A44-817B-3BE1-BF33F4E5B692','342','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1320','fringilla','6C796910-7B39-1AEC-0D5C-3D297BED4A40','223','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1325','ut, sem. Nulla','9D6ABDE7-98F8-4DE9-343E-12AAB1196DE4','932','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1330','non, dapibus rutrum,','5F0C0578-E481-CD3D-688B-DE96B9F49BF6','160','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1335','amet','F0DF2456-2068-8609-CA49-6757D16B1B97','261','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1340','urna justo','311CA1DB-28A6-FA44-678C-0203B476E714','400','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1345','dignissim tempor','12FD5B4A-CC29-FF78-26F2-DF434413C27B','363','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1350','amet,','F7FF4732-6CC8-F3B8-461A-4417673BF880','118','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1355','et ultrices','3C0582D8-624D-2687-C1E6-351B654B0252','250','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1360','vel sapien','0E290CDE-FD74-1BA6-D84D-7F1E9AD5BF05','372','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1365','nunc.','5A4C58AF-ECEA-9BCF-31EA-8F5E657C2E4F','940','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1370','convallis in,','DAFBA0EC-ACD0-E0D6-BF58-0E188EC71F9E','176','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1375','mi lacinia mattis.','879811F2-0DC3-9ECF-A9ED-64B4F4D0EF40','441','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1380','massa.','13A2238B-21C3-516A-AB18-8940E68D3D15','98','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1385','taciti','11173B16-DB78-127D-661C-0414551A0712','702','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1390','elit, pellentesque a,','10DFF731-09C4-F4C7-2FC7-4A139BA5D956','705','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1395','pretium et, rutrum','49F8DBF8-ACBD-2D70-CCBC-841841AE5A30','70','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1400','nibh.','1BD5BBFD-8FD1-C7CD-E97D-DCB35F47706D','849','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1405','sagittis. Duis','2CBFAF9B-77A3-FBB9-B708-7DFAE22D26B3','21','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1410','ac','79F7B954-51B0-0C06-BBD6-C8569F1BAC34','458','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1415','ultricies','9559C654-5CE5-6833-0445-C5820B713870','169','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1420','egestas','1D9DD100-F9F1-8EC5-01FE-619CCB2BCB50','759','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1425','justo. Praesent luctus.','D732FA7E-B7FF-B947-B1F3-DA7E8C143175','447','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1430','a','A621E070-F2EC-20FA-A235-E4D15C054E08','945','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1435','nunc','A527BE50-BA91-B9D6-1546-21DC5F832800','867','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1440','Cum','3BBD657D-8298-55CC-B4D6-35DE6B38275A','469','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1445','et, lacinia vitae,','FEEE335A-8F38-F837-39E0-85EABB788799','662','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1450','pede.','02D03658-5720-885E-238E-F2B6ABA83658','467','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1455','amet risus.','27AF75F5-E976-F5EC-51AF-3AD1E89AF225','905','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1460','et magnis dis','32D24CD8-39C8-9438-8BF3-F838C675A757','262','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1465','interdum. Curabitur','D8674EDC-6FE9-98ED-5D6F-39EDC7919F82','154','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1470','aliquam arcu.','88E3C730-5898-AD2D-A31D-EA2CBA382684','136','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1475','dolor dolor,','DA420941-4B4F-5B53-2F13-214BF9B09018','940','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1480','dolor, tempus','F4E05EE4-A80A-93F1-6315-778B16511CDF','222','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1485','eget, dictum','7C720981-290B-8409-C6F1-05017C430573','60','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1490','adipiscing, enim','A5C4A0B9-24AF-B28E-D42F-F151F8FC434F','3','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1495','luctus lobortis. Class','C1F40B48-B72A-3596-DE31-56F57CD4B3FF','428','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1500','pellentesque massa lobortis','27E82933-D7B2-EEE2-77EC-B0E74578AAF8','357','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1505','placerat. Cras dictum','3D50E0E6-3F28-B41F-1B23-9A8BBE411A4D','963','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1510','In mi','FE7EC113-8F46-1754-A075-0483B78FF9EF','93','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1515','auctor vitae,','959B8597-8272-CE62-E57F-24ABE2ABB98B','423','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1520','Pellentesque ut ipsum','CB98834F-1B66-F618-2228-DFB352E04BDA','460','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1525','Cum sociis natoque','C7433FCC-77FA-762F-E760-0571ECBBE762','251','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1530','eget laoreet posuere,','37A39F76-CD28-5E23-A55F-705704700B4A','596','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1535','pede nec','BA7D5411-15C5-A57A-59EC-65A219E13158','244','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1540','lobortis tellus justo','94155EE8-2CC9-9A94-E866-3C7EF2C08F16','624','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1545','dictum sapien.','7E9BEEB4-E395-B8A8-938B-BB545D3AAA3F','251','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1550','faucibus','98E5020A-C4A1-E35A-F1E2-7FCFA6F02F5A','614','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1555','aliquet','209B6E16-62F6-A160-9C24-64D2FCAF4159','4','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1560','eros nec tellus.','689FEF41-13E6-190C-E6D7-EF11F0F675B2','601','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1565','risus. Donec','91D7ABC9-F41D-5C5E-FB5A-3CEF1D27247C','751','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1570','laoreet','21C554AF-D95F-A14F-CAA7-A1AF06513CA6','954','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1575','Aliquam','AF321956-C952-97AD-72AF-9A4265DF3389','830','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1580','Integer vitae nibh.','5AB8F0E4-0388-ADA9-02BF-72A272347E13','232','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1585','sit amet ultricies','47DCFE1F-0789-870B-8354-A1EAD3BEA285','4','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1590','venenatis lacus.','24861C98-4ED5-9E16-09A1-1E2E995D183A','738','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1595','eu dui.','60C696EC-B7C6-5C6F-635B-1A1606BEE706','726','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1600','et magnis','83F2D604-1191-C239-1E10-FB06864A7F31','154','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1605','tempus','561B7DD3-36AE-1CD7-B96C-9A112FAAD022','498','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1610','sed leo.','9926C625-3527-39EC-9978-C2AD7F5AED4D','402','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1615','vitae risus.','8A6C3C04-2A70-EFDC-0805-F0E510AEBFFA','117','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1620','turpis','9BF268BE-0974-3EFD-DB7B-DC2EDE7955A0','664','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1625','Suspendisse tristique','17AEC907-1F63-4434-E65C-7994213B6543','698','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1630','faucibus. Morbi vehicula.','A1B6C333-13CE-99A7-E8FB-753FD4901892','866','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1635','auctor. Mauris','925E02BA-18D0-FD35-A81F-D2022BA8CB9B','117','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1640','massa. Integer vitae','F83FDC36-F61F-6670-35B5-3BC8BCAE5A61','113','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1645','Donec feugiat metus','B5B2DAFC-2838-D504-672F-DC4CBAC4AE29','351','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1650','egestas. Sed','5CE7DC2E-97A8-1539-A9F7-532155CC949A','906','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1655','lobortis augue scelerisque','7ED8040D-C253-FB12-4C42-89A5D2CD483C','423','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1660','Donec sollicitudin adipiscing','C8EA95DF-C07A-5037-F6CE-A79BDF60CE86','832','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1665','sagittis.','C069465D-2D63-79C3-6B18-41A55CE256E5','217','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1670','euismod et, commodo','4700D8B6-3912-3EB1-5C79-5D3E893556A5','66','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1675','diam luctus','351F7BD8-5938-6E88-3483-7CE92F5F926A','357','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1680','sem. Nulla interdum.','3016DDBB-09C0-C945-7E5D-E16830E1692B','437','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1685','cursus,','88BB532C-5F6A-446F-CD0E-1C4F0D90B4BB','234','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1690','eget lacus. Mauris','054E74F0-E322-624A-D255-F8EF1F354FA8','506','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1695','rutrum.','33842754-6AA4-D445-A032-C2FF2FA31399','276','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1700','pharetra. Quisque ac','8D127EA4-85A7-18F7-EB57-12F68E971562','553','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1705','parturient','C4B24626-34B1-EDE5-5247-BBD9CAA3401D','865','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1710','risus, at fringilla','8C3C6250-D891-7733-412D-38F041E4365D','963','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1715','congue. In','73BBDA96-1D61-6DFA-24E1-DD5DE2776A30','741','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1720','Cras','8FBE613E-1898-73C8-4545-F078FF8E28FC','724','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1725','tincidunt','7DFD4AB2-CA40-E8A1-4EFD-DDF393F7BC89','840','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1730','amet,','2C12E88D-1E4D-1D4C-2E3F-C3A9B3AA0F93','26','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1735','magna.','7C80E7EF-5EA9-9B05-0304-1590EF63FA67','441','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1740','Donec feugiat','C1C4E489-16D6-997B-F2E4-75285ABD3ECD','282','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1745','dictum augue malesuada','7110AD37-7B8C-9914-CEA3-88003F6040B7','779','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1750','dui. Suspendisse ac','7CE26EA1-BC8C-86A4-10F4-80657AA76308','940','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1755','tellus, imperdiet non,','470DBC41-B1A9-A2C1-8259-536E1427671D','359','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1760','orci','65A0E597-B1BB-6DCF-37B9-9DE4608AC0C0','86','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1765','enim.','401E7C1D-9A53-F7A3-0D0B-359BC3FBCDF7','288','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1770','augue','A14D6D35-B6B3-5CB8-0D14-6D8F18D36DB3','326','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1775','lacus.','22DE2B58-3AFC-B5BA-899B-D27CC1196232','490','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1780','convallis erat, eget','62D28C6B-A80E-6AF7-B5B5-8EDB03527FE7','751','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1785','urna.','53196AF2-27A4-3BFB-70B1-5CFA65A5A554','794','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1790','nec tempus mauris','231A9475-8F3D-216E-66AF-1D56B35A6F4C','718','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1795','sem','8C0343AC-9CCD-2D31-106E-FD70D14818E2','944','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1800','eu dolor egestas','22138412-C8FC-22EE-8358-153417FD7400','388','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1805','Cras sed','69BD70CE-543E-222C-5B24-B13D20E2005F','313','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1810','varius et,','23746F2F-4C45-31DF-773C-27EEA3F410BB','487','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1815','Praesent','7D29AE09-DE33-7812-7CE9-1891C73C12DD','469','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1820','id','69DE3EE6-87A8-F3F4-0EC5-6C3A4FC9C674','935','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1825','sem elit, pharetra','3C0DA337-F13A-D5F2-7DDB-58553E2D160D','238','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1830','dui augue','A12D1871-D562-C90B-FBFB-D8DFDB71DC77','24','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1835','tellus. Suspendisse sed','AC96D7BC-05C5-FBE2-2976-4355D3B5309D','366','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1840','vel arcu','33A170AA-C991-A0AC-7760-30E317A6A57E','760','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1845','tristique','2940D762-A135-58FB-5EBA-CAB3D6DBB1F8','322','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1850','lectus rutrum urna,','A398A00A-B2B0-95C1-6BCE-118AD620094D','66','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1855','Proin','D6942BDB-408C-30A0-2AAD-1A889AC607A6','861','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1860','malesuada. Integer','7ED0950E-7589-177B-3E99-258527D9FFE7','447','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1865','ut, nulla.','7D2B7EF2-F231-CF05-2F4D-7C363631B4A1','407','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1870','lobortis','5C3C7A5A-85B3-5CE9-4DCB-03E648B63567','259','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1875','imperdiet, erat','F4891CE8-0F7B-98F4-4F0A-CA5F820C6891','155','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1880','tellus justo','0A55C627-4CAF-2394-24F2-E331DFAD04C6','899','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1885','amet','D5C974B7-8E9B-8589-CB90-566BAEA61A20','273','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1890','Mauris','B329862C-2D71-F744-FFFC-E7DE1907E05D','607','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1895','in','C3A96551-850E-1093-2FA3-0395D14820B4','55','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1900','ultricies ligula.','9F8E8C76-0D79-4B6A-5CA8-2768173C1F07','637','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1905','ipsum sodales purus,','DDC1794B-8D0C-A044-6781-8666DE0F7348','386','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1910','amet, consectetuer','DB6FC9CC-E8BC-49CB-7C89-8BD01E69699D','328','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1915','Nunc pulvinar arcu','AC52F0AB-4002-6DFB-7056-EBAAB110925F','359','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1920','lobortis','8DE98C71-70B4-43C2-6DE7-FD79A9E94414','781','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1925','montes, nascetur ridiculus','CB8B3668-4D66-476A-6C9D-9796FCA1C769','610','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1930','nec','8C8A2933-F251-D891-1161-1D139E90F6AC','560','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1935','tellus lorem eu','1A00C3BE-886B-18AD-520F-DEE7DF586ED2','571','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1940','a','CC7F41B8-47A0-AE78-E767-85FB0922BFD5','557','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1945','non, dapibus','DBEA75A5-4311-735D-0161-62A9C464DC4C','355','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1950','nisi. Mauris','A229A009-E204-99A2-C906-A65BC33907AD','17','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1955','mi tempor','D23CE646-5A97-8D26-85B3-D59DFD04D73C','290','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1960','pretium','E89F4548-893A-0BB1-CF2A-E2339A3F75E8','348','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1965','Quisque','FCD249D8-FA43-8F8C-0850-65BFB69523B0','913','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1970','Nunc lectus','3D739CA9-3120-FB6F-B7D9-61B5978526AC','431','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1975','dictum. Phasellus','744F348B-5381-B0E1-7AF5-B9DB125619B6','390','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1980','Aliquam ultrices iaculis','597D4369-DE56-1826-1A0B-F5F60456D8A5','742','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1985','est arcu ac','C9E5A7E0-DBC5-2708-DF71-4B80C49964D6','923','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1990','nunc risus','D3EEBF94-C08A-FA08-9979-4706D975ED44','247','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('1995','dignissim pharetra. Nam','917D43BB-C931-690B-54E9-871962F4A968','308','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2000','sem egestas blandit.','D77ED537-85A4-B720-93CC-95D13D4E265A','386','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2005','cursus','17B2A098-6E16-78EC-05E0-B27E5E2C5335','155','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2010','eu arcu. Morbi','42296F37-56A3-25DB-4AA5-93DBD73DD387','378','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2015','non dui nec','3B1CAA1E-C7C7-2DCE-D804-28E2F7E7435D','492','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2020','Donec egestas.','C104EC22-53C5-965E-1D9C-21B05C934151','587','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2025','adipiscing. Mauris','90B9DDAE-9927-01EB-10B5-825D173F7B8B','763','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2030','Ut tincidunt','8D4B18FE-6408-EEBA-27DC-962D3F3E3001','244','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2035','convallis,','E1153E8E-6AFB-21FB-D071-FAEFADF894DB','801','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2040','id sapien.','C285AC83-3C8D-1FF6-7A16-D0A2F92B7475','418','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2045','at, iaculis','6F8F77C7-874F-F03B-9FA8-1608C5841605','735','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2050','Praesent interdum ligula','8F55E541-B923-1337-82AE-424037441995','13','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2055','magna nec quam.','59233145-E30C-33F7-0203-525F8907981C','210','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2060','imperdiet','99AC132E-351A-9F80-F539-8772DC706FFB','325','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2065','amet nulla. Donec','3680D7EE-7E36-1FF4-04E2-DE3F5258DA31','160','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2070','orci','AA755E7E-ACB2-0D43-E665-4ED09CEFF1F1','12','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2075','lobortis. Class aptent','676EF1D3-BB21-DAAB-ABF2-24DF3525D86B','689','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2080','magna. Phasellus dolor','11DD9174-36C9-1E65-4E09-6E70BCC0AD59','896','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2085','eget odio.','41899E87-45CF-408E-805A-89A7C018C672','379','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2090','auctor ullamcorper, nisl','8678FD9A-90FF-3326-E411-5FEB801C368D','585','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2095','ut quam','82F506D0-3EE5-F29E-67FB-5E94E35D73DE','825','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2100','Quisque varius.','EA06D1E7-3F09-153E-DCE0-638EB938E418','729','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2105','orci lobortis','A1AFCA8D-55E3-2064-92F1-37A5441F80B1','642','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2110','eu, eleifend nec,','E4236B89-7F3A-722D-2ABC-1D558D933838','693','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2115','tristique','C3619EB2-44A9-3CE4-0034-D2583B3F04DA','171','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2120','in faucibus','794AF464-94E6-BC1B-F90E-678E184DDBFD','701','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2125','Nulla eu','E443ED0A-0446-E86F-6A9F-D0978394161A','427','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2130','Cum sociis','8B127694-5C0E-1855-E009-77CE37CCCADA','978','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2135','diam at','0C47A98A-75DC-C736-2A19-75A9FB2DC606','110','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2140','nulla ante, iaculis','193CDD84-5B8E-6800-EC2C-A13738CBDF59','620','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2145','Nunc ullamcorper,','AD33910C-411B-8BAB-A3A1-A837A953B2A9','691','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2150','sit amet, consectetuer','4F36E075-FE55-C185-0DE1-9A02B05CD7EF','501','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2155','Duis','99DA5BBD-16BA-6189-F7F0-8ADE085A9A6F','298','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2160','tempor augue','3CFA9816-6C6C-FCF8-AF1F-5AA5690A000E','290','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2165','eu,','3CAA3DA1-8793-D04A-7DD2-86FBA2B9C48D','743','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2170','scelerisque','19F0D7F4-9DBF-A2D5-5B69-119815C3AA8C','219','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2175','sed pede. Cum','762AD1B2-3C84-F185-53A6-C9C5F9520D76','603','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2180','Cras eu','2C88A197-E1D7-479F-4BB8-F642AA680B06','625','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2185','enim, sit amet','BD3F6E27-30D8-81DA-F3EB-C78AE77043DF','134','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2190','pellentesque eget, dictum','C71EAF23-F3A8-D1FE-4D47-DFF909F1F80F','967','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2195','consequat nec, mollis','89024B89-0395-9227-1EF5-2CA58D9ADFD4','422','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2200','consectetuer rhoncus. Nullam','5FFFEBA4-2778-1D59-5ECE-77DAB036FB39','108','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2205','dictum eu, placerat','7CAF8031-FFF5-E98E-E92B-CF5577A3B81B','588','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2210','varius. Nam','D99F7B6B-E93E-4F39-8FDC-8002ABE2E769','97','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2215','ac nulla.','2D59DA87-C133-4E26-C884-A4201C4C0AAF','575','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2220','Proin','EB66581A-3E64-5C8E-8919-B47E88AD4C0B','653','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2225','lectus quis massa.','F21185AC-26C5-C5B3-D7A1-BC4823717856','578','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2230','iaculis nec, eleifend','6C78D182-48BC-59CD-DC30-0B22749C2B4F','222','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2235','ultricies ornare, elit','D93CBCA4-0FF4-969D-7A20-7087E000D421','279','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2240','mauris blandit','4A56252E-E84B-4186-358D-09F8E54BA50E','410','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2245','metus. Aliquam','7A41AC6E-0EE0-8F50-F8A2-E75E12E8EE8E','995','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2250','imperdiet ullamcorper.','1495257A-B908-A2CD-DAE2-8D90CC112835','154','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2255','ut, nulla. Cras','581729B2-29EF-4375-74CD-7D3E3E3BE833','374','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2260','non, cursus non,','FEA6A36E-6A84-1085-EF5B-5FE9E04D246B','266','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2265','magna','FD5E6ACE-A96B-B983-5D2D-946A1331DEF9','516','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2270','lectus','1CC5D4AB-8A90-7D8E-933D-B67E4DF558A1','556','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2275','viverra.','2C1D68C6-FD20-A7A7-9379-6263460261D1','286','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2280','sed consequat auctor,','BF62F337-C7CC-E4A0-ED01-AE06A8AF9F0B','640','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2285','sit amet','94C4DD6F-65D0-B9CC-5867-7527D61D97D1','936','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2290','urna','1D7D0113-170A-14EF-61D6-18121F180AE5','60','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2295','ridiculus','B8623B53-9BFB-45CA-E3C2-63230E351094','907','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2300','nulla.','92010023-5A24-310B-E59D-4FE24B85C3E8','164','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2305','Suspendisse ac','63C3D4A3-4414-23A5-6D1E-FA68D1481792','109','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2310','erat','C1F8BCED-02DB-1E8A-0A6C-AF2CB027CB06','604','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2315','vitae,','53CF37F0-0255-1641-D76C-E3F148281A42','191','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2320','feugiat','C6B6D2D4-D1BA-1216-C6EE-AED04E564D87','588','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2325','montes, nascetur ridiculus','74B4B28D-2480-BBE0-7CF1-1123AEDC6911','465','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2330','quis','6413092D-2CD8-D0B1-7C8C-0E5E9C203CCF','309','11');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2335','egestas rhoncus. Proin','D21F3FAF-1CD6-FD56-8C84-51D1F3FA3207','342','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2340','nonummy ac,','170822FC-22CF-6B9C-CE9C-8F88C6758258','9','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2345','laoreet','DA2125C6-1EF8-AFF9-A963-169B63047699','906','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2350','mauris. Integer','AF8D4FF2-7687-36DE-DFAC-A399F504DF73','35','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2355','vitae purus','97B430DD-CC15-F250-F593-770A36871AE9','284','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2360','sed,','01E2F4CA-9F3A-20F3-E8F6-5872AC6D2884','327','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2365','lorem fringilla','13936668-0EAE-C373-9D30-08AF8105C102','724','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2370','Integer vulputate,','BD9CB8AF-B0A3-C00C-D59B-6D3C635A749E','74','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2375','fames','C9E67590-0E9A-D513-2C22-ED013FC43C9C','510','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2380','elementum','EE5DD4EF-0E56-4B44-8A38-AF9FA5984157','205','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2385','dis parturient','32BE1104-7853-9318-19EC-D978B0E54066','988','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2390','vulputate, nisi','834025C4-F4C8-3B0F-01B1-83EFC2BC9FDA','135','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2395','Sed dictum.','FEE2DB67-1843-AB7C-76EC-479C4F06B01F','584','5');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2400','lobortis, nisi','77AA345C-091E-8095-C7FE-58E1B4A77168','148','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2405','lobortis quis,','589AC1C0-980B-21AE-7B45-35104A68BBAD','847','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2410','accumsan','2FA09401-2E1A-0A5E-0EC7-6E5F9A5D7BD3','841','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2415','arcu. Sed et','04788646-1191-669A-341C-00D2E1BD79F4','212','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2420','lectus, a','06388900-015E-96E1-D400-CCE0CFFD9381','848','6');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2425','sem, consequat','A2F11A95-EFAD-523C-BBE5-F3DC90F549FC','90','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2430','sed dictum eleifend,','8E8CEA40-E171-83CB-6A9E-598600AA3EE1','930','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2435','Proin eget','7FC090A0-07F4-5C09-6DBA-948853D2E572','786','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2440','Aenean massa. Integer','A2F5AF1B-3B79-1DC3-03A7-06D6D6966C91','774','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2445','Donec est. Nunc','292EB759-875F-5AFA-3C67-3299B55AD697','397','7');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2450','gravida molestie','92B7FB23-3F0A-FEAA-3E6F-E3FE8D1292CC','967','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2455','egestas','DFE18899-FD8E-232A-F6A5-63079774FBC5','499','8');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2460','Integer tincidunt','86273302-D5D6-4C7D-3725-7C2618FB6F15','566','1');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2465','ac risus.','9027BFA5-433F-8EC6-D205-5AF184B1CF69','884','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2470','convallis erat,','A2339094-D22A-6B77-89B1-7E527560B04D','944','2');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2475','Nulla eget','B50C312C-F531-9492-B163-07BC45665080','71','3');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2480','odio tristique pharetra.','3BB2E704-0FC0-F52D-E648-9B4D28FCD4C9','733','4');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2485','nibh. Donec est','3707FDBC-5A23-CB84-1DB1-0EF42672DE3A','488','10');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2490','et nunc.','913024EE-7FCF-5A35-FCD5-AC9F26C3AD98','792','9');
Insert into PRODUCTS ("id","name","reference","price","category_id") values ('2495','Quisque ornare','CEDE07B9-3D1F-851C-4589-C9F8B6DCB2C1','461','3');
--------------------------------------------------------
--  Constraints for Table ANSWERS
--------------------------------------------------------

  ALTER TABLE "ANSWERS" ADD PRIMARY KEY ("id") ENABLE
  ALTER TABLE "ANSWERS" MODIFY ("id" NOT NULL ENABLE)
--------------------------------------------------------
--  Constraints for Table CATEGORIES
--------------------------------------------------------

  ALTER TABLE "CATEGORIES" ADD CONSTRAINT "CK_Type_Weather" CHECK ("season" IN ('winter', 'summer', 'spring', 'autumn')) ENABLE
  ALTER TABLE "CATEGORIES" ADD PRIMARY KEY ("id") ENABLE
  ALTER TABLE "CATEGORIES" MODIFY ("id" NOT NULL ENABLE)
--------------------------------------------------------
--  Constraints for Table PRODUCTS
--------------------------------------------------------

  ALTER TABLE "PRODUCTS" ADD CONSTRAINT "CK_rode" CHECK ("price" > 0) ENABLE
  ALTER TABLE "PRODUCTS" ADD PRIMARY KEY ("id") ENABLE
  ALTER TABLE "PRODUCTS" MODIFY ("category_id" NOT NULL ENABLE)
  ALTER TABLE "PRODUCTS" MODIFY ("id" NOT NULL ENABLE)
